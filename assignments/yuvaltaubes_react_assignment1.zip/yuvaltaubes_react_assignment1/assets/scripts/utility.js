function selectID(selector, parent = document) {
    return parent.getElementById(selector)
}

export {selectID}
