const db = {
    'data': [
        {
            brand: 'audi',
            src: 'https://images.unsplash.com/photo-1608506436795-af65d01305bf?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=880',
            source: 'unsplash',
            price: "$90 000",
            zeroToSixty: "1.23",
            Inventory: '2',
        },
        
        {
            brand: 'Mclaren',
            src: 'https://images.unsplash.com/photo-1578545565737-22fb1162448f?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=876',
            source: 'unsplash',
            price: "$120 000",
            zeroToSixty: "4.21",
            Inventory: '5',

        },
        
        {
            brand: 'ferrari',
            src: 'https://images.unsplash.com/photo-1626036938027-aafe35e3e479?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=880',
            source: 'unsplash',
            color:'red',
            price: "$556 000",
            zeroToSixty: "6.12",

            Inventory: '1',

            
        },

        
        {
            brand: 'Mercedes Benz',
            src: 'https://images.unsplash.com/photo-1530861579116-b19f2dbf0ca3?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1209',
            source: 'unsplash',
            color:'black',
            
            price: "$21 000",
            zeroToSixty: "10.53",
            Inventory: '5',

        },
        

        {
            brand: 'Porsche',
            src: 'https://images.unsplash.com/photo-1604041679865-a506e0e30ad2?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=880',
            source: 'unsplash',
            price: "$500 000",
            zeroToSixty: "3.4",
            name: 'Porsche taycan',
            Inventory: '8',

        },
        {
            brand: 'mercedes benz',
            src: 'https://images.unsplash.com/photo-1548712494-4853e9e3293b?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=850',
            source: 'unsplash',
            price: "$60 000",
            zeroToSixty: "5.1",
            Inventory: '8',

        },
        {
            brand: 'ford',
            src: 'https://images.unsplash.com/photo-1652033763869-c9ac02b30e78?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=822',
            source: 'unsplash',
            price: "$12 000",
            zeroToSixty: "12.4",
            Inventory: '12',

        },
        {
            brand: 'ferrari',
            src: 'https://images.unsplash.com/photo-1626037032248-1ac252c8ccc3?ixlib=rb-1.2.1&raw_url=true&q=80&fm=jpg&crop=entropy&cs=tinysrgb&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=880',
            source: 'unsplash',
            price: "$500 000",
            zeroToSixty: "6.12",
            Inventory: '1',

        },
        {
            brand: 'Lamboghirni',
            src: 'https://images.unsplash.com/photo-1623671152179-0721615ce0d1?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=868',
            source: 'unsplash',
            price: "$520 000",
            zeroToSixty: "5.23",
            Inventory: '2',

        },
        {
            brand: 'Porsche',
            src: 'https://images.unsplash.com/photo-1573541685170-ab9580ca12c9?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=881',
            source: 'unsplash',
            price: "$190 000",
            zeroToSixty: "1.67",
            name: 'Porsche taycan',
            Inventory: '0',

        },
        {
            brand: 'ford',
            src: 'https://images.unsplash.com/photo-1524498303429-9da73d31c743?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=880',
            source: 'unsplash',
            price: "$20",
            zeroToSixty: "never",
            Inventory: '0',

        },
        {
            brand: 'Volkswagon',
            src: 'https://images.unsplash.com/photo-1606385077626-79ab87df3ba1?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=832',
            source: 'unsplash',
            price: "$10",
            zeroToSixty: "29.5",
            Inventory: '6',

        },
    ]
};

export default db